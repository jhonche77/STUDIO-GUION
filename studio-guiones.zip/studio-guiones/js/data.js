// ============================================================
//  Studio Guiones — Datos estáticos
// ============================================================

const TOPICS = [
  "Cómo ser más disciplinado sin motivación",
  "El hábito que cambió mi productividad",
  "Por qué nunca terminas lo que empiezas",
  "Cómo tomar decisiones más rápido",
  "El error que cometen los que quieren cambiar",
  "Cómo salir de tu zona de confort sin miedo",
  "Por qué leer no es suficiente para crecer",
  "La técnica de las 2 minutos para cualquier meta",
];

const STEPS = [
  { title: "Genera el guion", text: 'en la pestaña "Generador". Descarga el archivo .txt.' },
  { title: "Abre NotebookLM", text: "(notebooklm.google.com) → Crea un nuevo cuaderno con el nombre del tema." },
  { title: "Importa el guion:", text: "Sube el .txt como fuente. NotebookLM generará preguntas y resúmenes automáticos." },
  { title: "Genera el Audio Overview:", text: 'Haz clic en "Generar resumen de audio". Obtendrás un podcast de ~2 min ideal como referencia o voz en off.' },
  { title: "Graba tu video:", text: "Usa el guion original. Máximo 60 segundos. Habla frente a cámara o usa plantilla con texto + música." },
  { title: "Edita en CapCut o Canva:", text: "Añade subtítulos automáticos, música de tendencia y 2-3 gráficos visuales." },
  { title: "Publica en TikTok:", text: "Mejor horario: 7-9 am o 6-9 pm hora local. Añade 3-5 hashtags específicos + 1 amplio." },
  { title: "Cross-post en Reels:", text: "Espera 2 horas después de TikTok. Usa la misma descripción adaptada a Instagram." },
];

const PHASES = [
  {
    title: "🌱 Fase 1 — De 0 a 1,000 seguidores",
    items: [
      "Publica 1 video diario usando guiones de esta herramienta",
      "Acepta colaboraciones gratuitas a cambio de mención",
      "Construye tu email list desde el día 1 (Beehiiv o Substack)",
      "Ofrece 1 sesión de mentoría a bajo costo para validar tu expertise",
      "Meta: 3 testimonios reales de personas a las que ayudaste",
    ],
  },
  {
    title: "📈 Fase 2 — De 1,000 a 10,000 seguidores",
    items: [
      "Crea un producto digital básico: guía PDF o mini-curso en Gumroad ($9-$27)",
      "Activa el Fondo TikTok o programa de creadores (si aplica en tu país)",
      "Solicita colaboraciones pagas con marcas pequeñas del nicho",
      "Lanza un grupo de Telegram/WhatsApp de pago ($5-$15/mes)",
      "Haz lives semanales para generar regalos virtuales y conexión",
    ],
  },
  {
    title: "🚀 Fase 3 — 10,000+ seguidores",
    items: [
      "Lanza un curso completo ($97-$297) usando tu contenido más viral",
      "Negocia sponsorships con marcas medianas ($300-$1,500 por video)",
      "Crea una membresía mensual con contenido exclusivo y Q&A",
      "Monetiza con affiliate marketing de productos que usas de verdad",
      "Considera un bootcamp intensivo en vivo (alta percepción de valor)",
    ],
  },
];
