// ============================================================
//  Studio Guiones — Lógica principal
// ============================================================

// ── Estado ──────────────────────────────────────────────────
let selectedTopic   = "";
let lastScript      = "";
let lastTitle       = "";
let savedScripts    = JSON.parse(localStorage.getItem("studioScripts") || "[]");

// ── Inicialización ───────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  renderTopics();
  renderSteps();
  renderPhases();
  renderCalendar();
  renderSaved();
});

// ── Navegación ───────────────────────────────────────────────
function showSection(id, btn) {
  document.querySelectorAll(".section").forEach(s => s.classList.remove("active"));
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  if (btn) btn.classList.add("active");
}

// ── Render: Temas sugeridos ──────────────────────────────────
function renderTopics() {
  const grid = document.getElementById("topicsGrid");
  grid.innerHTML = "";
  TOPICS.forEach(topic => {
    const chip = document.createElement("div");
    chip.className = "topic-chip";
    chip.textContent = topic;
    chip.addEventListener("click", () => selectTopic(topic, chip));
    grid.appendChild(chip);
  });
}

function selectTopic(topic, el) {
  document.querySelectorAll(".topic-chip").forEach(c => c.classList.remove("selected"));
  el.classList.add("selected");
  selectedTopic = topic;
  document.getElementById("customTopic").value = "";
}

function clearTopicSelection() {
  document.querySelectorAll(".topic-chip").forEach(c => c.classList.remove("selected"));
  selectedTopic = "";
}

// ── Render: Pasos NotebookLM ─────────────────────────────────
function renderSteps() {
  const container = document.getElementById("stepList");
  container.innerHTML = STEPS.map((s, i) => `
    <div class="step">
      <div class="step-num">${i + 1}</div>
      <div class="step-text"><strong>${s.title}</strong> ${s.text}</div>
    </div>
  `).join("");
}

// ── Render: Fases de monetización ────────────────────────────
function renderPhases() {
  const container = document.getElementById("phasesContainer");
  container.innerHTML = PHASES.map(p => `
    <div class="mono-phase">
      <h4>${p.title}</h4>
      <ul>${p.items.map(item => `<li>${item}</li>`).join("")}</ul>
    </div>
  `).join("");
}

// ── Render: Calendario ───────────────────────────────────────
function renderCalendar() {
  const now        = new Date();
  const year       = now.getFullYear();
  const month      = now.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDay   = new Date(year, month, 1).getDay();

  // Publicar cada 2 días
  const publishDays = new Set(
    Array.from({ length: daysInMonth }, (_, i) => i + 1).filter(d => (d - 1) % 2 === 0)
  );

  const dayNames = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
  const monthNames = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

  let html = `<p class="hint" style="margin-bottom:8px">${monthNames[month]} ${year}</p>`;
  html += '<div class="cal-grid">';
  html += dayNames.map(d => `<div class="cal-header">${d}</div>`).join("");

  for (let i = 0; i < firstDay; i++) {
    html += `<div class="cal-day empty"></div>`;
  }

  for (let d = 1; d <= daysInMonth; d++) {
    const isPublish = publishDays.has(d);
    const isToday   = d === now.getDate();
    html += `
      <div class="cal-day ${isPublish ? "publish" : ""} ${isToday ? "today" : ""}">
        <div class="num">${d}</div>
        ${isPublish ? '<div class="label">📹</div>' : ""}
      </div>`;
  }

  html += `</div>
    <p class="hint" style="margin-top:10px">📹 = publicación sugerida (cada 2 días). Ajusta según tu ritmo.</p>`;

  document.getElementById("calContainer").innerHTML = html;
}

// ── Render: Guardados ────────────────────────────────────────
function renderSaved() {
  const list = document.getElementById("savedList");
  if (!savedScripts.length) {
    list.innerHTML = '<div class="empty-state">📭 Aún no hay guiones guardados.<br>Genera uno y presiona "Guardar".</div>';
    return;
  }
  list.innerHTML = savedScripts.map(s => `
    <div class="saved-item">
      <div class="saved-item-info">
        <div class="saved-item-title">🎬 ${escapeHtml(s.title)}</div>
        <div class="saved-item-meta">Guardado el ${s.date}</div>
      </div>
      <div class="saved-item-btns">
        <button class="btn btn-secondary btn-sm" onclick="viewSaved(${s.id})">👁 Ver</button>
        <button class="btn btn-green btn-sm"     onclick="downloadSaved(${s.id})">⬇️</button>
        <button class="btn btn-danger btn-sm"    onclick="deleteSaved(${s.id})">🗑</button>
      </div>
    </div>
  `).join("");
}

// ── Generador de guion (API Anthropic) ───────────────────────
async function generateScript() {
  const custom   = document.getElementById("customTopic").value.trim();
  const topic    = custom || selectedTopic;
  const tono     = document.getElementById("tono").value;
  const audiencia = document.getElementById("audiencia").value;
  const apiKey   = document.getElementById("apiKey").value.trim();

  if (!topic) {
    alert("Selecciona o escribe un tema primero.");
    return;
  }

  const btn        = document.getElementById("generateBtn");
  const outputCard = document.getElementById("outputCard");
  const output     = document.getElementById("scriptOutput");
  const outputBtns = document.getElementById("outputBtns");

  btn.disabled    = true;
  btn.textContent = "⏳ Generando...";
  outputCard.style.display = "block";
  outputBtns.style.display = "none";
  output.innerHTML = '<div class="loading"><div class="spinner"></div> Creando tu guion…</div>';

  const prompt = buildPrompt(topic, tono, audiencia);

  try {
    const headers = { "Content-Type": "application/json" };
    if (apiKey) headers["x-api-key"] = apiKey;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err?.error?.message || `HTTP ${response.status}`);
    }

    const data = await response.json();
    const text  = data.content?.map(i => i.text || "").join("\n") || "Sin respuesta.";

    output.textContent  = text;
    lastScript          = text;
    lastTitle           = topic;
    outputBtns.style.display = "flex";

  } catch (err) {
    output.textContent = `❌ Error: ${err.message}\n\nRevisa tu API Key o intenta de nuevo.`;
  }

  btn.disabled    = false;
  btn.textContent = "⚡ Generar Guion";
}

function buildPrompt(topic, tono, audiencia) {
  return `Eres un experto en contenido viral educativo para TikTok y Reels.
Crea un guion completo para un video de 60 segundos sobre: "${topic}"
Tono: ${tono} | Audiencia: ${audiencia}

Usa EXACTAMENTE esta estructura:

🎬 TEMA: ${topic}
⏱ DURACIÓN ESTIMADA: [X segundos]
🎯 OBJETIVO: [qué aprende el espectador]

---

[GANCHO]
(Primera frase que detiene el scroll, 0-3 seg. Fórmulas válidas: "¿Sabías que...?", "El error más común al...", "Nadie te dice esto sobre...", "En X segundos te explico...")

[PROMESA]
(Una sola oración: qué aprenderá el espectador)

[CONTENIDO]
Punto 1: [título]
[explicación + ejemplo. Máx 15 palabras por oración]

Punto 2: [título]
[explicación + ejemplo]

Punto 3: [título]
[explicación + ejemplo]

[REMATE]
(Dato inesperado o giro que refuerza por qué vale la pena seguirte)

[LLAMADA A LA ACCIÓN]
(Una sola acción concreta: seguir, comentar, guardar o compartir)

---

💡 NOTAS DE PRODUCCIÓN:
- Tono sugerido: ${tono}
- Visuals recomendados: [qué mostrar en pantalla]
- Música: [ritmo sugerido]

Reglas: brevedad brutal, una idea por video, concreto > abstracto, gancho en 3 segundos.`;
}

// ── Acciones sobre el guion generado ────────────────────────
function copyScript() {
  if (!lastScript) return;
  navigator.clipboard.writeText(lastScript).then(() => {
    flashBtn(event.target, "✅ Copiado!", "📋 Copiar");
  });
}

function downloadScript() {
  if (!lastScript) return;
  downloadText(lastScript, `guion_${slug(lastTitle)}.txt`);
}

function saveScript() {
  if (!lastScript) return;
  const entry = {
    id:     Date.now(),
    title:  lastTitle,
    script: lastScript,
    date:   new Date().toLocaleDateString("es-MX"),
  };
  savedScripts.unshift(entry);
  persistSaved();
  renderSaved();
  flashBtn(event.target, "✅ Guardado!", "💾 Guardar");
}

// ── Acciones sobre guiones guardados ─────────────────────────
function viewSaved(id) {
  const s = savedScripts.find(x => x.id === id);
  if (!s) return;
  lastScript = s.script;
  lastTitle  = s.title;

  // Ir a la pestaña Generador y mostrar el guion
  const genBtn = document.querySelector(".nav-btn");
  showSection("generador", genBtn);

  const outputCard = document.getElementById("outputCard");
  const output     = document.getElementById("scriptOutput");
  outputCard.style.display = "block";
  output.textContent = s.script;
  document.getElementById("outputBtns").style.display = "flex";
}

function downloadSaved(id) {
  const s = savedScripts.find(x => x.id === id);
  if (s) downloadText(s.script, `guion_${slug(s.title)}.txt`);
}

function deleteSaved(id) {
  savedScripts = savedScripts.filter(x => x.id !== id);
  persistSaved();
  renderSaved();
}

// ── Utilidades ───────────────────────────────────────────────
function persistSaved() {
  localStorage.setItem("studioScripts", JSON.stringify(savedScripts));
}

function downloadText(text, filename) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href     = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function slug(str) {
  return str.slice(0, 30).replace(/\s+/g, "_").replace(/[^a-zA-Z0-9_áéíóúñ]/g, "");
}

function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function flashBtn(btn, successText, originalText) {
  btn.textContent = successText;
  setTimeout(() => { btn.textContent = originalText; }, 2000);
}
